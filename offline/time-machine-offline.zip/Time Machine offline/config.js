"use strict";
// The offline copy talks to nobody: no account service and no game server.
window.ROME_CONFIG = { supabaseUrl: "", supabaseAnonKey: "", serverUrl: "" };
