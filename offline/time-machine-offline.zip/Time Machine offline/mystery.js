"use strict";
// Mysteries: 🔎 Mystery in the menu. Each city has a whodunit besides its story (story.js): Rome "The Poisoned Amphora", Old Delhi "The Stolen Saffron", Cancún "The Missing Jade Mask", Beijing "The Vanished
// Painting". Three clues wait at three famous places (in any order): stand there and a witness tells you one thing about the culprit. Then you have four suspects, each described in full, and exactly one of
// them fits all three clues. Accuse the right one for a big reward; a wrong accusation costs 20 denarii and clears that suspect. Solve the first case and a harder second one opens in the same city (Rome *The Loosened
// Wheel*, Delhi *The Poisoned Chai*, Cancún *The Missing Calendar Stone*, Beijing *The Forged Edict*): four clues, five suspects, and every wrong suspect fits three of the four. Progress is kept in the browser (rome-mystery) and the saved game.
// TEAM CASES (👥 Team tab): start one of the cases with friends (they must be online and have you as a friend): each of the clues is held by one of the team, who has to stand at its place, and everybody sees
// what has been found; when the team names the culprit each is paid the case's reward and 100 more (twice an hour at most). The game server (server.py, "team cases") keeps the team.
// A THIRD case in each city (Rome *The Counterfeit Denarii*, Delhi *The Missing Ledger*, Cancún *The Silent Drum*, Beijing *The Stolen Imperial Tea*) opens when the second is solved: five clues, the last two told
// only by citizens (chat with them, then ask), six suspects, 600 denarii. (Team cases are for the first two cases.)
// Depends on vitals.js, the landmarks of each city (by id) and the globals of game.js (LANDMARKS, city, player, startDirections, Narrator, openPanel, closePanels).

const Mystery = (() => {
  const KEY = "rome-mystery", FINE = 20;
  // clues: [landmark id, the witness's words, the trait it shows (0 to 2)]; traits: each suspect has [a, b, c] as 0/1 (1 = fits the clue), the culprit fits all three
  const EASY = {
    rome: { name: "The Poisoned Amphora", reward: 250, intro: "A wine seller has been taken ill after drinking from an amphora that was left at his stall in the Forum. The guards say it was poisoned, and that a stranger bought the amphora and put it there. Find out who.",
      clues: [
        ["forum", "A baker in the Forum saw the stranger buy the amphora: 'His fingers were stained deep red, like a dyer's.'", "stained red fingers"],
        ["colosseum", "At the Colosseum a ticket-seller remembers a man leaving in a hurry: 'The hobnails of his boots rang on the stones.'", "hobnailed boots"],
        ["circus", "At the Circus Maximus a charioteer chatted with the man: 'He spoke Latin with a Greek accent, I would swear to it.'", "a Greek accent"],
      ],
      suspects: [
        ["Dionysios, the wine merchant", "Red-stained fingers from tasting new wine, hobnailed boots from the vineyards, born in Athens.", [1, 1, 1], "Dionysios wanted to ruin his rival's stall and take his place in the Forum."],
        ["Quintus, the dyer", "Red-stained fingers from his vats, hobnailed boots, speaks the purest Latin of the Palatine.", [1, 1, 0], ""],
        ["Theon, the physician", "Fingers stained red by his medicines, soft sandals, a Greek accent.", [1, 0, 1], ""],
        ["Marcus, the legionary", "Clean hands, hobnailed boots, and an accent from Athens, where he served.", [0, 1, 1], ""],
      ] },
    delhi: { name: "The Stolen Saffron", reward: 250, intro: "A whole chest of saffron, worth more than a house, has vanished from a spice merchant's shop in Chandni Chowk overnight. The lock was not forced. Somebody who knew the shop did this.",
      clues: [
        ["d-chandni", "A tea seller in Chandni Chowk saw someone leave the lane at dawn: 'A green turban, bright as a parrot.'", "a green turban"],
        ["d-katra", "In the Katra a cloth merchant heard the thief pass: 'Tap, tap, tap: a cane with a brass handle.'", "a brass-handled cane"],
        ["d-jama", "On the steps of the Jama Masjid a scribe remembers the man asking the way in Persian, the language of the court.", "Persian speech"],
      ],
      suspects: [
        ["Rustam, the carpet seller", "Wears a green turban, walks with a brass-handled cane, and speaks Persian at home.", [1, 1, 1], "Rustam's debts had piled up, and saffron is easy to sell in a city of cooks."],
        ["Hari, the chai seller", "A green turban and a brass-handled cane, but he speaks only Hindi.", [1, 1, 0], ""],
        ["Zafar, the poet", "A green turban and Persian verses, but he walks with a plain bamboo stick.", [1, 0, 1], ""],
        ["Imran, the jeweller", "A brass-handled cane and the finest Persian in the bazaar, but he wears a white turban.", [0, 1, 1], ""],
      ] },
    cancun: { name: "The Missing Jade Mask", reward: 250, intro: "The jade mask of the temple of Kukulcán, kept for the equinox ceremony, has gone from its alcove at Chichén Itzá. The equinox is near, and the priests are in despair. Somebody took it.",
      clues: [
        ["c-castillo", "A priest at El Castillo noticed a feather on the stair: 'A quetzal feather, green as the jungle: only a noble wears it.'", "a quetzal-feather headdress"],
        ["c-warriors", "At the Temple of the Warriors a guard saw the thief run past: 'Blue paint on the face, like the rain god's priests.'", "blue face paint"],
        ["c-venus", "At the Platform of Venus a child saw the man hide something: 'He had the mark of a snake on his arm.'", "a serpent tattoo"],
      ],
      suspects: [
        ["Chaac-Mo, the noble", "Quetzal-feather headdress, blue face paint for the rain ceremonies, a serpent tattoo.", [1, 1, 1], "Chaac-Mo hoped that without the mask the priests would turn to him to lead the equinox."],
        ["Ix Chel, the weaver", "Quetzal feathers woven into her hair and blue paint, but no tattoo.", [1, 1, 0], ""],
        ["Balam, the ball player", "A serpent tattoo and a quetzal headdress he won, but his face is painted red.", [1, 0, 1], ""],
        ["Kinich, the priest", "Blue paint and a serpent tattoo, but only a plain cotton headband.", [0, 1, 1], ""],
      ] },
    beijing: { name: "The Vanished Painting", reward: 250, intro: "A famous scroll painting of mountains and mist has disappeared from the study of an official in the Forbidden City's lanes. The window was open, and nothing else was touched. A person who loves painting did this.",
      clues: [
        ["b-meridian", "A guard at the Meridian Gate recalls a visitor at dusk: 'His sleeves were black with ink to the elbow.'", "ink-stained sleeves"],
        ["b-drum", "At the Drum Tower a watchman heard footsteps: 'One foot fell lighter than the other. A limp, a bad one.'", "a limp"],
        ["b-summer", "At the Summer Palace a boatman remembers a passenger asking about pearls: 'A white jade ring on his thumb.'", "a white jade ring"],
      ],
      suspects: [
        ["Master Gu, the calligrapher", "Ink-stained sleeves to the elbow, a limp from an old fall, a white jade ring on his thumb.", [1, 1, 1], "Master Gu had always believed the painting was his by right: his teacher's last work."],
        ["Lin, the scholar", "Ink-stained sleeves and a limp, but no ring: he sold it last winter.", [1, 1, 0], ""],
        ["Madam Wu, the collector", "Ink on her sleeves from her seals, a white jade ring, but she walks lightly and well.", [1, 0, 1], ""],
        ["Feng, the antiques dealer", "A limp and a white jade ring, but his sleeves are always clean.", [0, 1, 1], ""],
      ] },
  };

  // the second case of each city is harder: four clues, five suspects, and each clue is a thing seen or heard rather than a name; each wrong suspect fails exactly one of them. It opens when the first case is solved.
  const HARD = {
    rome: { name: "The Loosened Wheel", reward: 400, intro: "Before the great race at the Circus Maximus, someone loosened the wheel of the favourite's chariot, and the driver was hurt. The racing stable wants the culprit found before the next race.",
      clues: [
        ["circus", "A groom at the Circus Maximus smelled olive oil on the hands of someone by the stable gate: 'Thick on his fingers, as if he had been pouring it all morning.'", "hands slippery with olive oil"],
        ["colosseum", "A guard at the Colosseum noticed a hooded man hurrying away: 'He dragged his left leg, every second step.'", "a limp in the left leg"],
        ["forum", "A moneychanger in the Forum remembers a man who paid with an old bronze coin of Nero: 'Nobody pays with those any more.'", "an old coin of Nero"],
        ["vesta", "A Vestal outside the Temple of Vesta heard him swear: 'By Mithras!' It is the oath of soldiers.", "an oath to Mithras"],
      ],
      suspects: [
        ["Cassius, the oil seller who was a soldier", "Sells oil by the jar, limps from an old wound in the left leg, keeps Nero's coins as keepsakes, and swears by Mithras like his old comrades.", [1, 1, 1, 1], "Cassius had bet his savings against the favourite, and a limping soldier knows exactly how a wheel pin comes out."],
        ["Brutus, the oil merchant", "Pours oil all day, limps on the left leg, collects old coins of Nero, but is a devoted follower of Jupiter.", [1, 1, 1, 0], ""],
        ["Livius, the stable master", "Oils the wheels, drags his left leg since a kick from a horse, swears by Mithras, but pays only in new coins.", [1, 1, 0, 1], ""],
        ["Nero Ofilius, the coin dealer", "Oily hands from a lamp he mends, swears by Mithras, deals in old coins of Nero, but walks without a limp.", [1, 0, 1, 1], ""],
        ["Gnaeus, the retired legionary", "Limps on the left leg, swears by Mithras and pays in old coins of Nero, but his hands are dry and clean.", [0, 1, 1, 1], ""],
      ] },
    delhi: { name: "The Poisoned Chai", reward: 400, intro: "A cup of chai served to a Mughal officer in Chandni Chowk was poisoned. The officer lived, but the whole bazaar is frightened. Somebody who knew his daily habits did it.",
      clues: [
        ["d-lahori", "A guard at the Lahori Gate saw the person leave: 'He spat red on the ground: betel, the paan of the markets.'", "teeth stained by betel"],
        ["d-fatehpuri", "At the Fatehpuri mosque a gardener noticed a ring: 'A silver ring with a lotus on it, flashing as he reached for the cup.'", "a silver lotus ring"],
        ["d-serai", "In the caravanserai a camel driver heard the stranger ask for water: 'He spoke like a man from Rajasthan.'", "a Rajasthani accent"],
        ["d-rangmahal", "At the Rang Mahal a servant remembers a red cloth bag he never put down: 'He held it close, like a child.'", "a red cloth bag"],
      ],
      suspects: [
        ["Bhanu, the herb seller", "Chews betel all day, wears a silver lotus ring, speaks with a Rajasthani accent, and carries his herbs in a red cloth bag.", [1, 1, 1, 1], "Bhanu had been paid by a rival spice merchant to frighten the officer's favourite chaiwala out of business."],
        ["Chandu, the paan seller", "Betel-stained teeth, a silver lotus ring and a Rajasthani accent, but he keeps his goods in a brown basket.", [1, 1, 1, 0], ""],
        ["Mohan, the silversmith", "Betel-stained teeth, a red cloth bag, a Rajasthani accent, but he wears a plain gold band.", [1, 0, 1, 1], ""],
        ["Rekha, the cloth trader", "A silver lotus ring, a red bag and a Rajasthani accent, but her teeth are white and clean.", [0, 1, 1, 1], ""],
        ["Wajid, the Lucknow cook", "Betel-stained teeth, a silver lotus ring, a red bag, but he speaks the soft Urdu of Lucknow.", [1, 1, 0, 1], ""],
      ] },
    cancun: { name: "The Missing Calendar Stone", reward: 400, intro: "A small carved stone that the astronomers use to keep the count of days has vanished from the Caracol at Chichén Itzá. Without it the priests cannot announce the date of the next festival.",
      clues: [
        ["c-caracol", "At the Caracol an astronomer found jade dust on the floor: 'Someone with jade ear plugs knocked the case.'", "jade ear plugs"],
        ["c-columns", "Among the Thousand Columns a sweeper saw a flash of red: 'A cape of red cotton, the colour of the sun god's priests.'", "a red cotton cape"],
        ["c-sacbe", "On the white road a trader met the thief: 'He had the accent of the coast, from Tulum.'", "the accent of Tulum"],
        ["c-tzompantli", "At the Tzompantli a child saw him hide something and make a sign of the jaguar with his hand.", "the jaguar sign"],
      ],
      suspects: [
        ["Itzamna, the scribe", "Jade ear plugs, a red cotton cape, the accent of Tulum, and he makes the sign of the jaguar when he is nervous.", [1, 1, 1, 1], "Itzamna wanted the calendar stone for himself: whoever keeps the count of days keeps the power over the festivals."],
        ["Yaxche, the stone carver", "Jade ear plugs, a red cotton cape and the accent of Tulum, but he makes the sign of the eagle.", [1, 1, 1, 0], ""],
        ["Ahau, the trader", "Jade ear plugs, the accent of Tulum and the jaguar sign, but his cape is blue.", [1, 0, 1, 1], ""],
        ["Ixchel, the weaver", "A red cotton cape, the accent of Tulum and the jaguar sign, but no ear plugs at all.", [0, 1, 1, 1], ""],
        ["Kukul, the runner", "Jade ear plugs, a red cotton cape and the jaguar sign, but he speaks like the people of the high country.", [1, 1, 0, 1], ""],
      ] },
    beijing: { name: "The Forged Edict", reward: 400, intro: "An edict with the Emperor's seal appeared in the Forbidden City ordering a grain store to be opened to a stranger. The seal was real; the handwriting was copied. Someone with a very skilled brush did this.",
      clues: [
        ["b-heaven", "A priest at the Temple of Heaven noticed the courier's hand: 'A hard callus on his middle finger: the mark of years of holding a brush.'", "a calligrapher's callus"],
        ["b-hutong", "In a hutong a neighbour smelled him pass: 'Sandalwood, the kind scholars burn when they write.'", "the scent of sandalwood"],
        ["b-bell", "At the Bell Tower the keeper heard the courier ask for the time: 'The soft speech of Suzhou in the south.'", "the soft speech of Suzhou"],
        ["b-bridge", "On the marble bridge a boy saw a hand with the tip of the little finger missing, holding a seal case.", "a missing little fingertip"],
      ],
      suspects: [
        ["Shen, the retired clerk", "A callus on his middle finger, a scent of sandalwood, the speech of Suzhou, and the tip of his little finger lost to a gate.", [1, 1, 1, 1], "Shen had been dismissed without a pension, and he wanted the grain store opened to a friend who would pay him well."],
        ["Wen, the court painter", "A callus, sandalwood and the speech of Suzhou, but all ten fingers whole.", [1, 1, 1, 0], ""],
        ["Qiu, the incense seller", "Sandalwood, the speech of Suzhou and a missing fingertip, but no writer's callus: he cannot write.", [0, 1, 1, 1], ""],
        ["Lu, the northern scribe", "A callus, sandalwood and a missing fingertip, but he speaks the hard speech of the north.", [1, 1, 0, 1], ""],
        ["Mei, the fan maker", "A callus, the speech of Suzhou and a missing fingertip, but she smells of lacquer, not sandalwood.", [1, 0, 1, 1], ""],
      ] },
  };

  // the third case of each city is the hardest: five clues, the last two told by citizens only (a clue whose place is null is not at any sight: chat with the citizens, see rumor() below), and six suspects, each wrong one failing
  // exactly one clue. It opens when the second case is solved.
  const THIRD = {
    rome: { name: "The Counterfeit Denarii", reward: 600, intro: "A chest of silver denarii at the Temple of Saturn, the state treasury, has turned out to be full of coins that are lead under a thin coat of silver. Somebody has been making false money for months. The treasurer wants the forger found, quietly.",
      clues: [
        ["saturn", "A treasury clerk at the Temple of Saturn sniffed the counter where the false coins were paid in: 'Hot lead and charcoal. I would know that smell anywhere.'", "the smell of hot lead"],
        ["pantheon", "A priest at the Pantheon remembers a man who left a tiny silver wing as an offering: 'Mercury, god of merchants and thieves. He prayed for a good market.'", "a Mercury amulet"],
        ["palatine", "A guard on the Palatine Hill noticed a signet ring when the man showed his pass: 'A wild boar carved into the stone.'", "a boar signet ring"],
        [null, "Somebody in the city remembers how the man counted his coins at the inn: 'He used his left hand for everything, even the cup.'", "left-handed"],
        [null, "Somebody in the city remembers his face by the lamp: 'A pale scar across the chin, as if from a knife long ago.'", "a scar on the chin"],
      ],
      suspects: [
        ["Gellius, the mint worker", "Smells of hot lead from the melting pots, wears a Mercury amulet and a boar signet ring, is left-handed, and has a scar across the chin.", [1, 1, 1, 1, 1], "Gellius had worked at the mint for years, and saw how little it would take to stamp lead as silver in his spare hours."],
        ["Rufus, the plumber", "Smells of hot lead from his pipes, wears a Mercury amulet and a boar ring, is left-handed, but has a clean chin.", [1, 1, 1, 1, 0], ""],
        ["Aulus, the lamp maker", "Smells of hot lead, wears a Mercury amulet and a boar ring and has a chin scar, but writes and eats with his right hand.", [1, 1, 1, 0, 1], ""],
        ["Septimus, the bronzesmith", "Smells of lead and charcoal, is left-handed, has a chin scar and a Mercury amulet, but wears a ring with an eagle, not a boar.", [1, 1, 0, 1, 1], ""],
        ["Lucilla, the jeweller", "Smells of lead from soldering, wears a boar ring, is left-handed and has a chin scar, but prays to Venus and carries no wing of Mercury.", [1, 0, 1, 1, 1], ""],
        ["Pollio, the pewterer", "Wears a Mercury amulet and a boar ring, is left-handed and has a chin scar, but his workshop smells of tin and not of lead.", [0, 1, 1, 1, 1], ""],
      ] },
    delhi: { name: "The Missing Ledger", reward: 600, intro: "The great ledger of the tax collectors, which names who owes what to the Emperor, has vanished from the Diwan-i-Aam overnight. Without it nobody can prove a debt, and several nobles are suspiciously cheerful. Find the thief.",
      clues: [
        ["d-diwanaam", "A guard at the Diwan-i-Aam remembers a man who admired the hall at dusk: 'A turban pin shaped like a peacock, with a tiny blue stone.'", "a peacock turban pin"],
        ["d-chhatta", "In the Chhatta Chowk arcade a perfume seller noticed him pass: 'Rosewater, so strong that I thought a bride had walked by.'", "the scent of rosewater"],
        ["d-diwankhas", "At the Diwan-i-Khas a servant saw a hand reach for the door: 'A thick gold ring with a blue stone on the little finger.'", "a ring with a blue stone"],
        [null, "Somebody in the city overheard him at a stall: 'He bargained in Punjabi, fast and loud, like a man from Lahore.'", "Punjabi speech"],
        [null, "Somebody in the city remembers what he carried: 'A leather satchel with brass buckles. He never put it down, not even to eat.'", "a satchel with brass buckles"],
      ],
      suspects: [
        ["Dilawar, the revenue clerk", "A peacock pin in his turban, smells of rosewater, wears a gold ring with a blue stone, speaks Punjabi, and carries a leather satchel with brass buckles.", [1, 1, 1, 1, 1], "Dilawar had been passed over for promotion for years, and a lost ledger would make his superiors look careless and himself indispensable."],
        ["Karan, the cloth merchant", "A peacock pin, rosewater, a blue-stone ring and Punjabi at home, but he carries his goods in a plain cloth bundle.", [1, 1, 1, 1, 0], ""],
        ["Nasir, the scribe", "A peacock pin, rosewater, a blue-stone ring and a brass-buckled satchel, but he speaks the soft Urdu of Lucknow.", [1, 1, 1, 0, 1], ""],
        ["Pritam, the horse trader", "A peacock pin, rosewater, Punjabi and a brass-buckled satchel, but his ring has a red stone.", [1, 1, 0, 1, 1], ""],
        ["Farhan, the courtier", "A peacock pin, a blue-stone ring, Punjabi and a satchel with brass buckles, but he smells of sandalwood, not rosewater.", [1, 0, 1, 1, 1], ""],
        ["Omar, the book binder", "Rosewater, a blue-stone ring, Punjabi and a brass-buckled satchel, but his turban pin is a simple silver one.", [0, 1, 1, 1, 1], ""],
      ] },
    cancun: { name: "The Silent Drum", reward: 600, intro: "The great drum of the ball court, whose voice opens each game of pok-ta-pok, has been taken from its stand at Chichén Itzá. Without it the festival cannot begin, and the players are blaming each other. Find who took it.",
      clues: [
        ["c-ballcourt", "A player at the Great Ball Court remembers a man at the stand: 'He wore sandals of jaguar skin, which only the best players may wear.'", "jaguar-skin sandals"],
        ["c-cenote", "At the Sacred Cenote a diver saw someone throw a bead into the water: 'A bracelet of jade beads, one of them cracked.'", "a bracelet of jade beads"],
        ["c-warriors", "At the Temple of the Warriors a guard noticed red dust: 'Red ochre on both his hands, the paint of the drum makers.'", "red ochre on his hands"],
        [null, "Somebody in the city heard him humming as he walked: 'A song from the south, in the Chontal tongue, which hardly anyone here knows.'", "humming in the Chontal tongue"],
        [null, "Somebody in the city remembers him laughing: 'A front tooth missing, and a gap like a window when he smiled.'", "a missing front tooth"],
      ],
      suspects: [
        ["Hun-Ahau, the drum maker", "Jaguar-skin sandals, a jade bead bracelet, red ochre on his hands, a Chontal song on his lips, and a gap where a front tooth was.", [1, 1, 1, 1, 1], "Hun-Ahau thought the new drum was a poor copy of the one his grandfather made, and he meant to take back what he thought was his family's."],
        ["Balam-Itza, the star player", "Jaguar sandals, jade bracelet, red ochre from the ball paint and a Chontal song, but all his teeth are whole.", [1, 1, 1, 1, 0], ""],
        ["Ek-Chuah, the trader", "Jaguar sandals, jade bracelet, red ochre and a missing tooth, but he sings only in Yucatec.", [1, 1, 1, 0, 1], ""],
        ["Ixquic, the potter", "Jaguar sandals, jade bracelet, a Chontal song and a missing tooth, but her hands are grey with clay, not red.", [1, 1, 0, 1, 1], ""],
        ["Kan-Mo, the diver", "Jaguar sandals, red ochre, a Chontal song and a missing tooth, but he wears a bracelet of shells.", [1, 0, 1, 1, 1], ""],
        ["Zac-Nicte, the runner", "A jade bracelet, red ochre, a Chontal song and a missing tooth, but she goes barefoot.", [0, 1, 1, 1, 1], ""],
      ] },
    beijing: { name: "The Stolen Imperial Tea", reward: 600, intro: "A sealed chest of the finest tea, grown for the Emperor alone, has disappeared from the storeroom behind the Hall of Supreme Harmony. The seal was cut with a very thin blade. Someone who knows tea and who knows the palace did this.",
      clues: [
        ["b-harmony", "A eunuch at the Hall of Supreme Harmony remembers a visitor: 'A blue silk sash, tied in the style of the southern tea houses.'", "a blue silk sash"],
        ["b-jingshan", "On Jingshan Hill a gardener saw someone hiding something: 'A bamboo flute at his belt, the kind the street players use.'", "a bamboo flute at his belt"],
        ["b-lake", "At Kunming Lake a boatman remembers his muddy boots: 'Black mud from the lake shore, still wet. He had walked round the water.'", "boots black with lake mud"],
        [null, "Somebody in the city overheard him ask the price: 'He spoke with the singing accent of Shanxi, where the tea merchants come from.'", "a Shanxi accent"],
        [null, "Somebody in the city remembers what he carried: 'A red sandalwood abacus, polished by years of use, that clicked as he walked.'", "a red sandalwood abacus"],
      ],
      suspects: [
        ["Zhao, the tea broker", "A blue silk sash, a bamboo flute at his belt, boots black with lake mud, a Shanxi accent, and a red sandalwood abacus that clicks as he walks.", [1, 1, 1, 1, 1], "Zhao had promised a rich buyer in the south the Emperor's own tea, and he had no other way to keep the promise."],
        ["Yu, the street musician", "A blue sash, a bamboo flute, lake-mud boots and a Shanxi accent, but he carries no abacus: he cannot count.", [1, 1, 1, 1, 0], ""],
        ["Cheng, the grain merchant", "A blue sash, a flute, lake-mud boots and a red abacus, but he speaks the flat speech of the capital.", [1, 1, 1, 0, 1], ""],
        ["Hua, the fisherman", "A blue sash, a flute, a Shanxi accent and a red abacus, but his boots are clean: he fishes from a boat.", [1, 1, 0, 1, 1], ""],
        ["Ming, the tea-house owner", "A blue sash, lake-mud boots, a Shanxi accent and a red abacus, but he has no flute.", [1, 0, 1, 1, 1], ""],
        ["Lan, the silk trader", "A flute, lake-mud boots, a Shanxi accent and a red abacus, but her sash is green.", [0, 1, 1, 1, 1], ""],
      ] },
  };
  const CASES = {};
  for (const c of Object.keys(EASY)) CASES[c] = [EASY[c], HARD[c], THIRD[c]];

  // progress: per city, one entry per case: { c: [clue found 0/1...], ok: solved, no: suspects cleared }
  const blank = (c) => CASES[c].map((k) => ({ c: k.clues.map(() => 0), ok: 0, no: [] }));
  let prog = {}, sel = {};
  function clean(raw) {
    const out = {};
    for (const k of Object.keys(CASES)) {
      const r = raw && raw[k] ? raw[k] : null, list = Array.isArray(r) ? r : r ? [r] : [];             // (the first version kept one case per city as an object)
      out[k] = CASES[k].map((cs, n) => {
        const e = list[n] || {};
        return { c: cs.clues.map((_, i) => (Array.isArray(e.c) && e.c[i] ? 1 : 0)), ok: e.ok ? 1 : 0, no: Array.isArray(e.no) ? e.no.filter((x) => Number.isInteger(x) && x >= 0 && x < cs.suspects.length).slice(0, cs.suspects.length) : [] };
      });
    }
    return out;
  }
  try { prog = clean(JSON.parse(localStorage.getItem(KEY) || "null")); } catch (e) { prog = clean(null); }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(prog)); } catch (e) { /* ignore */ } };
  const tr = (t) => (typeof I18n !== "undefined" && I18n.t ? I18n.t(t) : t);
  const $s = (id) => document.getElementById(id);
  const lmOf = (id) => LANDMARKS.find((l) => l.id === id);
  const cityOf = () => (CASES[city] ? city : "rome");
  const openTo = (c) => (prog[c][0].ok ? (prog[c][1].ok ? 2 : 1) : 0);   // the second case opens when the first is solved, the third when the second is
  const open1 = openTo;
  const curIdx = (c) => { const top = openTo(c); if (sel[c] !== undefined) return Math.min(sel[c], top); for (let i = 0; i <= top; i++) if (!prog[c][i].ok) return i; return top; };
  const el = (tag, text, cls) => { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; if (cls) e.className = cls; return e; };
  function say(text) { toast(text.length > 160 ? text.slice(0, 157) + "..." : text); try { Narrator.say(text, { interrupt: true }); } catch (e) { /* ignore */ } }

  // the suspects are shown in a fixed order that does not give the culprit away (the data lists the culprit first)
  const suspectOrder = (c, n) => {
    const idx = CASES[c][n].suspects.map((_, i) => i), key = `${c}${n}`; let h = 0; for (const ch of key) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    for (let i = idx.length - 1; i > 0; i--) { h = (Math.imul(h, 1103515245) + 12345) >>> 0; const j = h % (i + 1); [idx[i], idx[j]] = [idx[j], idx[i]]; }
    if (idx[0] === 0) idx.push(idx.shift());
    return idx;
  };
  let team = null, teamView = false, teamOk = false;
  const CITY_NAMES = { rome: "Rome", delhi: "Old Delhi", cancun: "Cancún", beijing: "Beijing" };
  const tabsFor = (c, n) => {
    const tabs = el("div", undefined, "pm-tabs");
    CASES[c].forEach((k, i) => { const b = el("button", tr(i > openTo(c) ? `Case ${i + 1} 🔒` : ["Case 1", "Case 2: harder", "Case 3: the hardest"][i])); b.type = "button"; if (i === n && !teamView) b.className = "on"; b.disabled = i > openTo(c); b.addEventListener("click", () => { teamView = false; sel[c] = i; render(); }); tabs.append(b); });
    const tb = el("button", tr("👥 Team")); tb.type = "button"; if (teamView) tb.className = "on"; tb.addEventListener("click", () => { teamView = true; render(); if (typeof Online !== "undefined" && Online.connected) Online.navalSend({ t: "social", a: "co_me" }); }); tabs.append(tb);
    return tabs;
  };
  const csend = (o) => Online.navalSend({ t: "social", ...o });
  function renderTeam(body) {
    const c = cityOf(), n = curIdx(c), rows = [tabsFor(c, n)];
    const ready = typeof Online !== "undefined" && Online.connected && typeof Account !== "undefined" && Account.loggedIn;
    if (!team) {
      rows.push(el("p", tr("Solve a case with friends: each of you holds some of the clues and has to stand at the right place. When the team names the culprit, everybody is paid."), "dnote"));
      if (!ready) rows.push(el("p", tr("Team cases need your account and the game server: log in and wait to be connected."), "dnote"));
      for (const k of [0, 1]) {
        const b = el("button", `${tr("Start a team case")}: ${tr(CASES[c][k].name)} (${tr(CITY_NAMES[c])})`); b.type = "button"; b.disabled = !ready || k > openTo(c);
        b.addEventListener("click", () => csend({ a: "co_make", city: c, n: k })); rows.push(b);
      }
      body.replaceChildren(...rows); return;
    }
    const cs = CASES[team.city][team.n], mem = team.members, here = team.city === city;
    rows.push(el("h3", `${tr(cs.name)} · ${tr(CITY_NAMES[team.city])}`), el("p", tr(cs.intro), "dnote"));
    rows.push(el("p", `👥 ${mem.map((m, i) => `${m.online ? "●" : "○"} ${m.name}${i === team.me ? ` (${tr("you")})` : ""}`).join(" · ")}`, "dnote"));
    if (!here) rows.push(el("p", `${tr("Travel to")} ${tr(CITY_NAMES[team.city])} ${tr("to look for the clues.")}`, "sk-note"));
    cs.clues.forEach((cl, i) => {
      const lm = lmOf(cl[0]), holder = mem[i % mem.length];
      if (team.found[i]) rows.push(el("p", `✓ ${tr(cl[1])} (${team.by[i]})`, "st-old"));
      else if (i % mem.length === team.me) {
        const row = el("p", `❓ ${tr("You hold this clue:")} ${lm ? tr(lm.name) : cl[0]}`, "st-now");
        if (lm && here) { const b = el("button", tr("Show me the way")); b.type = "button"; b.addEventListener("click", () => { closePanels(); if (typeof startDirections === "function") { try { startDirections(lm); } catch (e) { /* ignore */ } } }); row.append(" ", b); }
        rows.push(row);
      } else rows.push(el("p", `❓ ${holder ? holder.name : "?"} ${tr("holds this clue: ask them to find it.")}`, "st-now"));
    });
    const found = team.found.filter(Boolean).length;
    if (team.ok) rows.push(el("p", `${tr("Case closed:")} ${tr(cs.suspects.find((s) => s[2].every((v) => v))[3])}`, "sk-note"));
    else if (found < team.k) rows.push(el("p", `${found} ${tr("of")} ${team.k} ${tr("clues found.")}`, "dnote"));
    else {
      rows.push(el("h3", tr("Who did it?")), el("p", `${tr("All the clues are in:")} ${cs.clues.map((cl) => tr(cl[2])).join(", ")}. ${tr("Only one suspect fits them all. A wrong accusation costs 20 denarii.")}`, "dnote"));
      const ul = el("ul", undefined, "mk-items");
      suspectOrder(team.city, team.n).forEach((i) => {
        const s = cs.suspects[i], li = el("li"), txt = el("span"), cleared = team.no.includes(i), b = el("button", tr(cleared ? "Cleared" : "Accuse")); b.type = "button"; b.disabled = cleared; b.addEventListener("click", () => accuseTeam(i));
        txt.append(el("strong", tr(s[0])), el("small", tr(s[1]))); if (cleared) li.style.opacity = "0.5";
        li.append(txt, b); ul.append(li);
      });
      rows.push(ul);
    }
    const bar = el("div", undefined, "sk-menu");
    if (team.host && !team.ok) {
      const inv = el("button", tr("➕ Invite a friend")); inv.type = "button";
      inv.addEventListener("click", () => {
        const online = typeof Social !== "undefined" && Social.list ? Social.list().filter((f) => f.online) : [];
        if (!online.length) { toast(tr("None of your friends are online.")); return; }
        Dialog.ask(`${tr("Which friend? Type a name:")} ${online.map((f) => f.name).join(", ")}`, online[0].name).then((raw) => { const f = online.find((x) => x.name.toLowerCase() === String(raw || "").trim().toLowerCase()); if (f) csend({ a: "co_invite", fid: f.fid }); else if (raw !== null) toast(tr("No friend of that name is online.")); });
      });
      bar.append(inv);
    }
    const leave = el("button", tr("Leave the team")); leave.type = "button"; leave.addEventListener("click", () => csend({ a: "co_leave" })); bar.append(leave);
    rows.push(bar);
    body.replaceChildren(...rows);
  }
  function accuseTeam(i) {
    if (!team || team.ok || team.found.some((v) => !v)) return;
    const cs = CASES[team.city][team.n], s = cs.suspects[i];
    if (s[2].every((v) => v)) { csend({ a: "co_solve" }); say(`${tr(s[0])} ${tr("is the culprit!")} ${tr(s[3])}`); }
    else { csend({ a: "co_no", i }); Vitals.coins = Math.max(0, Vitals.coins - FINE); Sfx.play("oof"); toast(`${tr(s[0])} ${tr("has an alibi: wrong! −20 denarii. Think again about the clues.")}`); }
  }
  function onCoop(m) {
    if (m.a === "state") {
      const first = !team; team = m.s;
      if (first) toast(`👥 ${tr("Team case:")} ${tr(CASES[team.city][team.n].name)}`);
      if (team.ok && !teamOk) { teamOk = true; Sfx.play("medal"); toast(`🏆 ${tr("Your team solved the case! The reward is on its way.")}`); }
      if (!team.ok) teamOk = false;
      if ($s("mystery").classList.contains("show")) render();
    } else if (m.a === "end") { team = null; teamOk = false; if ($s("mystery").classList.contains("show")) render(); }
    else if (m.a === "invite") {
      Sfx.play("chime");
      Dialog.confirm(`${m.from} ${tr("invites you to a team case:")} ${tr(CASES[m.city][m.n].name)} (${tr(CITY_NAMES[m.city])}). ${tr("Join?")}`).then((yes) => { if (yes) { csend({ a: "co_join", sid: m.sid }); teamView = true; } });
    } else if (m.a === "clue_ok") {
      Vitals.coins += 10; Sfx.play("page"); Sfx.play("discover");
      if (team) say(`🔎 ${tr(CASES[team.city][team.n].clues[m.i][1])} (+10 ${tr("denarii")})`);
    } else if (m.a === "sent") toast(tr("Invitation sent."));
    else if (m.a === "no") toast(tr(m.text));
  }
  // the clues you hold in the team case are told when you stand at their places
  const told = {};
  function teamUpdate() {
    if (!team || team.ok || team.city !== city || team.me < 0) return;
    CASES[team.city][team.n].clues.forEach((cl, i) => {
      if (team.found[i] || i % team.members.length !== team.me || told[i] > performance.now() - 4000) return;
      const lm = lmOf(cl[0]); if (!lm) return;
      const d = Math.hypot(player.x - lm.x, player.z - lm.z), st2 = lm.stand ? Math.hypot(player.x - lm.stand[0], player.z - lm.stand[1]) : Infinity;
      if (d > (lm.r || 20) + 6 && st2 > 14) return;
      told[i] = performance.now(); csend({ a: "co_clue", i });
    });
  }
  function render() {
    const body0 = $s("my-body"); if (body0 && teamView) { $s("my-title").textContent = `🔎 ${tr("Mystery")}`; renderTeam(body0); return; }
    const c = cityOf(), n = curIdx(c), cs = CASES[c][n], p = prog[c][n], body = $s("my-body"); if (!body) return;
    $s("my-title").textContent = `🔎 ${tr(cs.name)}`;
    const rows = [];
    rows.push(tabsFor(c, n), el("p", tr(cs.intro), "dnote"));
    cs.clues.forEach((cl, i) => {
      const lm = lmOf(cl[0]);
      if (p.c[i]) rows.push(el("p", `✓ ${tr(cl[1])}`, "st-old"));
      else if (!cl[0]) { const w = witness(c, n, i); rows.push(el("p", `❓ ${tr("Nobody saw this one at a sight: ask the citizens.")}${w ? ` ${tr("Ask someone called")} ${w.name} ${whenText(w.when)}.` : ""}`, "st-now")); }
      else {
        const w = witness(c, n, i), row = el("p", `❓ ${lm ? tr(lm.name) : cl[0]}: ${tr("a witness may know something.")}${w ? ` ${tr("Or ask someone called")} ${w.name} ${whenText(w.when)}.` : ""}`, "st-now");
        if (lm) { const b = el("button", tr("Show me the way")); b.type = "button"; b.addEventListener("click", () => { closePanels(); if (typeof startDirections === "function") { try { startDirections(lm); } catch (e) { /* ignore */ } } }); row.append(" ", b); }
        rows.push(row);
      }
    });
    const found = p.c.filter(Boolean).length, total = cs.clues.length;
    if (p.ok) rows.push(el("p", `${tr("Case closed:")} ${tr(cs.suspects.find((s) => s[2].every((v) => v))[3])}`, "sk-note"));
    else if (found < total) rows.push(el("p", `${found} ${tr("of")} ${total} ${tr("clues found. Walk to the places above: the witnesses will find you.")}${cs.clues.some((cl) => !cl[0]) ? ` ${tr("Some clues come only from the citizens: chat with them first.")}` : ""}`, "dnote"));
    else {
      rows.push(el("h3", tr("Who did it?")));
      rows.push(el("p", `${tr("All the clues are in:")} ${cs.clues.map((cl) => tr(cl[2])).join(", ")}. ${tr("Only one suspect fits them all. A wrong accusation costs 20 denarii.")}`, "dnote"));
      const ul = el("ul", undefined, "mk-items");
      suspectOrder(c, n).forEach((i) => {
        const s = cs.suspects[i], li = el("li"), txt = el("span"), b = el("button", tr(p.no.includes(i) ? "Cleared" : "Accuse")); b.type = "button"; b.disabled = p.no.includes(i); b.addEventListener("click", () => accuse(i));
        txt.append(el("strong", tr(s[0])), el("small", tr(s[1]))); if (p.no.includes(i)) li.style.opacity = "0.5";
        li.append(txt, b); ul.append(li);
      });
      rows.push(ul);
    }
    body.replaceChildren(...rows);
  }
  function accuse(i) {
    const c = cityOf(), n = curIdx(c), cs = CASES[c][n], p = prog[c][n];
    if (p.ok || p.c.some((v) => !v)) return;
    const s = cs.suspects[i];
    if (s[2].every((v) => v)) {
      p.ok = 1; save(); Vitals.coins += cs.reward; Sfx.play("medal"); if (typeof Guilds !== "undefined") Guilds.score("mystery"); 
      say(`${tr(s[0])} ${tr("is the culprit!")} ${tr(s[3])} ${tr("The case is closed:")} +${cs.reward} ${tr("denarii")}.${n === 0 ? ` ${tr("A harder case is now open.")}` : n === 1 ? ` ${tr("The hardest case is now open.")}` : ""}`);
    } else {
      if (!p.no.includes(i)) p.no.push(i);
      Vitals.coins = Math.max(0, Vitals.coins - FINE); save(); Sfx.play("oof");
      toast(`${tr(s[0])} ${tr("has an alibi: wrong! −20 denarii. Think again about the clues.")}`);
    }
    render();
  }
  function open() { render(); openPanel("#mystery"); }

  // the citizens (lives.js) know things too: for each clue of the case you are working on, one name in the city knows what the witness saw, and tells you when you have chatted that day and
  // catch them at the right time of the day (at work, at lunch or in the evening)
  const WHEN = ["work", "lunch", "evening"], WHEN_TEXT = { work: "while they are at work", lunch: "at lunchtime", evening: "in the evening" };
  const hashS = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
  function witness(c, n, i) {
    const names = typeof Lives !== "undefined" && Lives.names ? Lives.names(c) : []; if (!names.length) return null;
    const base = hashS(`${c}${n}w`) % names.length, h = hashS(`${c}${n}${i}t`);                      // (the names of one case are all different: steps of 3 round ten names)
    return { name: names[(base + i * 3) % names.length], when: WHEN[h % 3] };
  }
  // the clues of the open case that this name knows, and the one case name (for the talk panel)
  function rumor(name) {
    const c = CASES[city] ? city : null; if (!c) return null;
    const n = curIdx(c), p = prog[c][n]; if (p.ok) return null;
    const i = CASES[c][n].clues.findIndex((cl, k) => !p.c[k] && witness(c, n, k) && witness(c, n, k).name === name);
    return i < 0 ? null : { i, caseName: CASES[c][n].name, when: witness(c, n, i).when };
  }
  // a chat that turned to the case: told (the clue is yours) or later (wrong time of day)
  function ask(name, planKey) {
    const r = rumor(name); if (!r) return { state: "none" };
    if (planKey !== r.when) return { state: "later", when: r.when };
    const c = cityOf(), n = curIdx(c), p = prog[c][n], cl = CASES[c][n].clues[r.i];
    p.c[r.i] = 1; save(); Vitals.coins += 10; Sfx.play("page"); Sfx.play("discover");
    toast(`🔎 ${tr(cl[1])} (${p.c.filter(Boolean).length} ${tr("of")} ${p.c.length} ${tr("clues")}, +10 ${tr("denarii")})`);
    if ($s("mystery").classList.contains("show")) render();
    return { state: "told", text: cl[1] };
  }
  const whenText = (w) => tr(WHEN_TEXT[w] || "");

  // a clue is told when you stand at its place (the clues of the case you are working on, and of the first case until it is solved)
  function update() {
    if (typeof started === "undefined" || !started || (mode !== "walk" && mode !== "drive")) return;
    teamUpdate();
    const c = CASES[city] ? city : null; if (!c) return;
    const n = curIdx(c), p = prog[c][n]; if (p.ok) return;
    CASES[c][n].clues.forEach((cl, i) => {
      if (p.c[i]) return;
      const lm = lmOf(cl[0]); if (!lm) return;
      const d = Math.hypot(player.x - lm.x, player.z - lm.z), st2 = lm.stand ? Math.hypot(player.x - lm.stand[0], player.z - lm.stand[1]) : Infinity;
      if (d > (lm.r || 20) + 6 && st2 > 14) return;
      p.c[i] = 1; save(); Vitals.coins += 10; Sfx.play("page"); Sfx.play("discover");
      say(`🔎 ${tr(cl[1])} (${p.c.filter(Boolean).length} ${tr("of")} ${p.c.length} ${tr("clues")}, +10 ${tr("denarii")})`);
      if ($s("mystery").classList.contains("show")) render();
    });
  }
  function bind() { const b = $s("btn-mystery"); if (b) b.addEventListener("click", open); }
  return {
    bind, update, open, CASES, rumor, ask, whenText, onCoop,
    snapshot: () => JSON.parse(JSON.stringify(prog)),
    restore(raw) { prog = clean(raw); save(); },
    get solved() { return Object.values(prog).reduce((n, list) => n + list.filter((e) => e.ok).length, 0); }, _prog: () => prog,
  };
})();
